require({cache:{
'url:epi-cms/contentediting/editors/templates/_BlockTreeNode.html':"﻿<div class=\"dijitTreeNode\" role=\"presentation\">\r\n    <div class=\"epi-tree-mngr--node-wrapper\" data-dojo-attach-point=\"rowNode\">\r\n        <span data-dojo-attach-point=\"rolesNode, _buttonNode\" class=\"epi-tree-mngr--view-settings\"></span>\r\n        <div class=\"dijitTreeRow dijitInline\" role=\"presentation\">\r\n            <div data-dojo-attach-point=\"indentNode\" class=\"dijitInline\"></div>\r\n            <span data-dojo-attach-point=\"expandoNode\" class=\"dijitTreeExpando\"></span>\r\n            <span data-dojo-attach-point=\"expandoNodeText\" class=\"dijitExpandoText\" role=\"presentation\"></span>\r\n            <span data-dojo-attach-point=\"contentNode\" class=\"dijitTreeContent\" role=\"presentation\">\r\n                <span data-dojo-attach-point=\"iconNode\" class=\"dijitIcon dijitTreeIcon\" role=\"presentation\"></span>\r\n                <span data-dojo-attach-point=\"labelNode\" class=\"dijitTreeLabel\" role=\"treeitem\" tabindex=\"-1\" aria-selected=\"false\"></span>\r\n                <span data-dojo-attach-point=\"extraIconsContainer\" class=\"epi-extraIconsContainer\" role=\"presentation\">\r\n                    <span data-dojo-attach-point=\"sharedIndicatorNode\" class=\"dijitTreeLabel dijitHidden epi-sharedIndicator\" tabindex=\"-1\" aria-selected=\"false\">${resources.shared}</span>\r\n                    <span data-dojo-attach-point=\"iconNodeMenu\" class=\"epi-extraIcon epi-pt-contextMenu\" title=\"${resources.settingstooltip}\" role=\"presentation\">&nbsp;</span>\r\n                </span>\r\n            </span>\r\n        </div>\r\n        <div data-dojo-attach-point=\"containerNode\" class=\"dijitTreeContainer\" role=\"presentation\" style=\"display: none;\"></div>\r\n    </div>\r\n</div>\r\n"}});
﻿define("epi-cms/contentediting/editors/_BlockTreeNode", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/keys",
    "dojo/dom-class",
    "dojo/on",
    "dojo/when",
    "dijit/Tree",
    "dijit/focus",
    "dijit/_HasDropDown",

    "epi/shell/applicationSettings",

    // epi-cms
    "epi-cms/widget/PersonalizationSelector",
    "epi-cms/dgrid/formatters",
    "./_ContentAreaTreeNodeMixin",

    // resources
    "epi/i18n!epi/cms/nls/episerver.cms.widget.blockcontextmenu",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.editors.contentarea",
    "dojo/text!./templates/_BlockTreeNode.html"
], function (
    // dojo
    declare,
    lang,
    keys,
    domClass,
    on,
    when,
    Tree,
    focusUtil,
    _HasDropDown,

    applicationSettings,

    // epi-cms
    PersonalizationSelector,
    formatters,
    _ContentAreaTreeNodeMixin,

    // resources
    tooltip,
    resources,
    template
) {

    return declare([Tree._TreeNode, _ContentAreaTreeNodeMixin, _HasDropDown], {
        // tags:
        //      internal

        templateString: template,

        _contextMenuClass: "epi-iconContextMenu",
        isExpandable: false,
        dropDownPosition: ["before"],
        resources: lang.mixin(tooltip, resources.personalize, { shared: resources.shared }),

        buildRendering: function () {
            this.inherited(arguments);

            this.dropDown = new PersonalizationSelector({ model: this.item });
            this.own(this.dropDown);
            this.aroundNode = this.domNode;
            this.set("readOnly", this.item.readOnly);

            domClass.add(this.domNode, "epi-tree-mngr--block");

            var node = this.rolesNode;

            // Get the icon from the type descriptor
            var iconClass = formatters.contentIconClass(this.item.typeIdentifier);
            domClass.add(this.iconNode, iconClass);

            node.innerHTML = this.item.get("rolesString");
            this.own(this.item.watch("rolesString", lang.hitch(this, function (property, oldValue, newValue) {
                node.innerHTML = newValue;
            })));

            this.own(this.item.watch("readOnly", lang.hitch(this, function () {
                this.set("readOnly", this.item.readOnly);
            })));

            this.own(on(this.item, "changed", function () {
                this.item.updateTooltip();
                this.set("item", this.item);
                this.set("label", this.item.label);
                this.set("tooltip", this.item.tooltip);
            }.bind(this)));

            if (this.item.isBrokenLink) {
                domClass.add(this.iconNode, "epi-iconWarning");
            }
        },

        setSelected: function (selected, internalSelect) {
            this.inherited(arguments);

            this.item.set("selected", selected);

            domClass.toggle(this.iconNodeMenu, this._contextMenuClass, selected);
        },

        showPersonalizationSelector: function () {
            if (this.readOnly) {
                return;
            }

            this.item.set("ensurePersonalization", false);

            focusUtil.focus(this.labelNode);

            this.loadAndOpenDropDown();
        },

        focus: function () {
            // summary:
            //      We need this method because _HasDropDown calls focus when toggling the dropdown
            this.labelNode.focus();
        },

        _onKey: function (/*Event*/ e) {
            // summary:
            //      We need to override the default behaviour otherwise the dropdown will popup
            //      when we click the downarrow on the tree node
            if (this.dropDown && this._opened && e.keyCode === keys.ESCAPE) {
                this.closeDropDown();
            }
        },

        _onKeyUp: function () {

        },

        _setItemAttr: function (item) {
            this._set("item", item);
            this.sharedIndicatorNode.classList.toggle("dijitHidden", !applicationSettings.inlineBlocksInContentAreaEnabled || (item && item.inlineBlockData));
        }
    });
});
