require({cache:{
'url:epi-cms/contentediting/templates/AllowedTypesList.html':"﻿<div>\r\n    <div data-dojo-attach-point=\"allowedTypesWrapper\" class=\"dijitHidden\">\r\n        <strong>${resources.allowedtypes}</strong>\r\n        <p data-dojo-attach-point=\"allowedTypesList\"></p>\r\n    </div>\r\n    <div data-dojo-attach-point=\"restrictedTypesWrapper\" class=\"dijitHidden\">\r\n        <strong>${resources.restrictedtypes}</strong>\r\n        <p data-dojo-attach-point=\"restrictedTypesList\"></p>\r\n    </div>\r\n</div>"}});
﻿define("epi-cms/contentediting/AllowedTypesList", [
    // dojo
    "dojo/_base/declare",
    "dojo/dom-class",

    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",

    // epi
    "epi/shell/TypeDescriptorManager",

    // resources
    "dojo/text!./templates/AllowedTypesList.html",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.contentreferencelisteditor"
], function (
    // dojo
    declare,
    domClass,

    // dijit
    _TemplatedMixin,
    _WidgetBase,

    // epi
    TypeDescriptorManager,

    // resources
    templateString,
    resources) {

    return declare([_WidgetBase, _TemplatedMixin], {
        // tags:
        //      internal

        templateString: templateString,

        // defaultAllowedTypedList: [public] String[]
        //    The default allowed types list
        defaultAllowedTypes: ["episerver.core.icontentdata", "episerver.core.icontent"],

        // _hasAllowedTypes: [private] Boolean
        //      Indicate whether there is any allowed types restriction
        _hasAllowedTypes: false,
        // _hasRestrictedTypes: [private] Boolean
        //      Indicate whether there is any restricted types restriction
        _hasRestrictedTypes: false,

        postMixInProperties: function () {
            this.inherited(arguments);
            this.resources = resources;
        },

        _setAllowedTypesAttr: function (allowedTypes) {
            this.allowedTypes = allowedTypes;
            if (this._hasAllowedTypesRestriction()) {
                this._hasAllowedTypes = true;
                domClass.remove(this.allowedTypesWrapper, "dijitHidden");
                this.allowedTypesList.innerHTML = this._convertToUserFriendlyNames(allowedTypes).join(", ");
            } else {
                this._hasAllowedTypes = false;
                domClass.add(this.allowedTypesWrapper, "dijitHidden");
            }
        },

        _setRestrictedTypesAttr: function (restrictedTypes) {
            if (!restrictedTypes || restrictedTypes.length === 0) {
                this._hasRestrictedTypes = false;
                domClass.add(this.restrictedTypesWrapper, "dijitHidden");
            } else {
                this._hasRestrictedTypes = true;
                domClass.remove(this.restrictedTypesWrapper, "dijitHidden");
                this.restrictedTypesList.innerHTML = this._convertToUserFriendlyNames(restrictedTypes).join(", ");
            }
        },

        _convertToUserFriendlyNames: function (types) {
            function onlyUnique(value, index, array) {
                return array.indexOf(value) === index;
            }

            return types.map(function (typeIdentifier) {
                return TypeDescriptorManager.getTypeName(typeIdentifier);
            }).filter(onlyUnique);
        },

        _getHasRestrictionAttr: function () {
            //  summary:
            //      Return true if there is any restriction which is not default

            return this._hasAllowedTypes || this._hasRestrictedTypes;
        },

        _hasAllowedTypesRestriction: function () {
            // summary:
            //      Return true if there is any restriction in allowedTypes which is not default

            if (!this.allowedTypes || this.allowedTypes.length === 0) {
                // allowedTypes doesn't exist
                return false;
            }

            // unlikely happens, but added to detect unwanted null exception
            if (!this.defaultAllowedTypes || this.defaultAllowedTypes.length === 0) {
                return true;
            }

            var defaultList = this.defaultAllowedTypes;
            if (this.allowedTypes.every(function (e) {
                return defaultList.includes(e);
            })) {
                // every item in allowedTypes is default restriction
                return false;
            }

            // restriction in allowedTypes exists which is not default.
            return true;
        }
    });
});
