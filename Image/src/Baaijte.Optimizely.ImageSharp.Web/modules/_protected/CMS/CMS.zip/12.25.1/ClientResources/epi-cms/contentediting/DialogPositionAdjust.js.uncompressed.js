﻿define("epi-cms/contentediting/DialogPositionAdjust", [
    "dojo/_base/declare",
    "dijit/Destroyable"
], function (
    declare,
    Destroyable
) {

    return declare([Destroyable], {
        // summary:
        //      Adjust dialog position in case of small browser window
        // tags:
        //      internal

        _resizeObserver: null,

        destroy: function () {
            this.cleanup();

            this.inherited(arguments);
        },

        adjustDialogPosition: function (dialog, resizeHandle) {
            if (this._resizeObserver) {
                this._resizeObserver.disconnect();
            }

            resizeHandle = resizeHandle || this._resizeHandle;
            this._resizeObserver = new ResizeObserver(function () {
                resizeHandle(dialog);
            });
            this._resizeObserver.observe(dialog.domNode);
        },

        _resizeHandle: function (dialog) {
            if (!dialog.domNode) {
                return;
            }
            var dialogSize = dialog.domNode.getBoundingClientRect();
            dialog.domNode.style.top = Math.round(window.innerHeight - dialogSize.height - 10) / 2 + "px";
        },

        cleanup: function () {
            if (this._resizeObserver) {
                this._resizeObserver.disconnect();
                this._resizeObserver = null;
            }
        }
    });
});
