define([], function (plugin) {
    return {
        start: function (mid, referenceModule, bc) {
            // This is just a dummy plugin to get rid of the missing plugin warnings when building.
            return [bc.amdResources["epi/i18n"]];
        }
    };
});
